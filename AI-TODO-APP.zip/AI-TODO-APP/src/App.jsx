import { useState, useEffect } from "react";

export default function App() {
  const [todos, setTodos] = useState(() => {
    // Load from localStorage if available
    const saved = localStorage.getItem("todos");
    return saved ? JSON.parse(saved) : [];
  });
  const [input, setInput] = useState("");
  const [reminderTime, setReminderTime] = useState("");
  const [editingId, setEditingId] = useState(null);
  const [popup, setPopup] = useState(null);

  // Save todos to localStorage whenever they change
  useEffect(() => {
    localStorage.setItem("todos", JSON.stringify(todos));
  }, [todos]);

  // Auto-hide popup
  useEffect(() => {
    if (popup) {
      const t = setTimeout(() => setPopup(null), 3000);
      return () => clearTimeout(t);
    }
  }, [popup]);

  // Check reminders every second
  useEffect(() => {
    const interval = setInterval(() => {
      const now = new Date();

      todos.forEach((todo) => {
        if (!todo.reminded && todo.reminder) {
          const reminderDate = new Date(todo.reminder);
          if (now >= reminderDate) {
            const sound = new Audio("https://actions.google.com/sounds/v1/alarms/beep_short.ogg");
            sound.play().catch(() => {});

            if (navigator.vibrate) {
              navigator.vibrate([200, 100, 200]);
            }

            setPopup({ text: todo.text });

            setTodos((prev) =>
              prev.map((t) =>
                t.id === todo.id ? { ...t, reminded: true } : t
              )
            );
          }
        }
      });
    }, 1000);

    return () => clearInterval(interval);
  }, [todos]);

  function addTodo() {
    if (input.trim() === "") return;

    if (editingId) {
      setTodos((prev) =>
        prev.map((todo) =>
          todo.id === editingId
            ? { ...todo, text: input, reminder: reminderTime, reminded: false }
            : todo
        )
      );
      setEditingId(null);
    } else {
      const newTodo = {
        id: Date.now(),
        text: input,
        reminder: reminderTime || null,
        reminded: false,
      };
      setTodos([...todos, newTodo]);
    }

    setInput("");
    setReminderTime("");
  }

  function deleteTodo(id) {
    setTodos(todos.filter((todo) => todo.id !== id));
  }

  function editTodo(todo) {
    setInput(todo.text);
    setReminderTime(todo.reminder || "");
    setEditingId(todo.id);
  }

  return (
    <div className="relative p-6 max-w-md mx-auto bg-gradient-to-r from-purple-500 to-pink-500 min-h-screen text-white">
      <h1 className="text-3xl font-extrabold mb-4 text-center drop-shadow-lg">
        ✨ Colorful Todo List + Reminders ✨
      </h1>

      <div className="mb-4 space-y-3 bg-white/20 backdrop-blur p-4 rounded-xl shadow-xl">
        <input
          className="border p-3 w-full rounded-xl text-black"
          placeholder="Enter a task..."
          value={input}
          onChange={(e) => setInput(e.target.value)}
        />

        <input
          type="datetime-local"
          className="border p-3 w-full rounded-xl text-black"
          value={reminderTime}
          onChange={(e) => setReminderTime(e.target.value)}
        />

        <button
          onClick={addTodo}
          className="bg-yellow-400 hover:bg-yellow-500 text-black font-bold px-4 py-2 rounded-xl w-full shadow-md"
        >
          {editingId ? "Update Todo" : "Add Todo"}
        </button>
      </div>

      <ul className="space-y-3">
        {todos.map((todo, index) => (
          <li
            key={todo.id}
            className="bg-white/20 backdrop-blur border border-white/30 p-4 rounded-xl flex justify-between items-center shadow-lg"
          >
            <div>
              <strong className="text-yellow-300">{index + 1}. </strong>
              <span className="font-semibold">{todo.text}</span>
              {todo.reminder && (
                <p className="text-xs text-white/70">
                  Reminder: {new Date(todo.reminder).toLocaleString()}
                </p>
              )}
            </div>

            <div className="flex gap-3">
              <button
                className="text-blue-300 font-bold"
                onClick={() => editTodo(todo)}
              >
                Edit
              </button>

              <button
                className="text-red-300 font-bold"
                onClick={() => deleteTodo(todo.id)}
              >
                X
              </button>
            </div>
          </li>
        ))}
      </ul>

      {popup && (
        <div className="fixed bottom-6 left-1/2 -translate-x-1/2 bg-white text-black px-6 py-4 rounded-2xl shadow-2xl animate-bounce drop-shadow-xl">
          🔔 Reminder: <strong>{popup.text}</strong>
        </div>
      )}
    </div>
  );
}
